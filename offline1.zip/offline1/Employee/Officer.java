package Employee;

import Bank.Bank;

public class Officer extends Employee {

    public Officer(String name, Bank bank) {
        super(name, bank);
    }

}
