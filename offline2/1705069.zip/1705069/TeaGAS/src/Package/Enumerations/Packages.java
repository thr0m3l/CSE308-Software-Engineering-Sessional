package Package.Enumerations;

public enum Packages {
    Silver,
    Diamond,
    Platinum,
    Gold
}
