package Device.Microcontroller;

public class RaspberryPi extends Microcontroller{
    public RaspberryPi() {
        super.setType("Raspberry Pi");
    }
}
