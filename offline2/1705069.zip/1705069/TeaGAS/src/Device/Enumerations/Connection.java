package Device.Enumerations;

public enum Connection {
    WIFI,
    GSM,
    Ethernet
}
