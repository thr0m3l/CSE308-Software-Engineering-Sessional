package Device.Enumerations;

public enum Microcontroller {
    ATMega32,
    ArduinoMega,
    RaspberryPi
}
