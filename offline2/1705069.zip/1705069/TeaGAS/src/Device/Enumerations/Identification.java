package Device.Enumerations;

public enum Identification {
    RFID,
    NFC
}
