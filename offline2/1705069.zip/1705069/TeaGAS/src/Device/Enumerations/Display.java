package Device.Enumerations;

public enum Display {
    TouchScreen,
    LED,
    LCD
}
