package Device.Enumerations;

public enum WeightMeasure {
    LoadSensor,
    WeightModule
}
