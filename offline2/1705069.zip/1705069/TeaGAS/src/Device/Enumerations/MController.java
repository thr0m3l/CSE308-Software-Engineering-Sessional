package Device.Enumerations;

public enum MController {
    ATMega32,
    ArduinoMega,
    RaspberryPi
}
