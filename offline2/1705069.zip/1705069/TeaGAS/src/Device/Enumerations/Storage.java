package Device.Enumerations;

public enum Storage {
    Internal,
    SDCard
}
