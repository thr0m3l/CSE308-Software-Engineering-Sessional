package Device.Enumerations;

public enum Controller {
    TouchScreen,
    Buttons
}
