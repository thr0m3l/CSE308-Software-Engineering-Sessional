package WebFramework;

public class Django extends WebFramework{
    Django() {
        super("Django", "Python");
    }
}
