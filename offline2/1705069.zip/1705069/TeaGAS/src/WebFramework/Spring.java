package WebFramework;

public class Spring extends WebFramework{
    Spring(){
        super("Spring", "Java");
    }
}
