package WebFramework;

public class Laravel extends WebFramework{
    Laravel() {
        super("Laravel", "PHP");
    }
}
