package Parser;

public class CppParser implements Parser{
    @Override
    public void parse() {
        System.out.println("Parsing cpp");
    }
}
