package Parser;

public class PyParser implements Parser {
    @Override
    public void parse() {
        System.out.println("Parsing python");
    }
}
