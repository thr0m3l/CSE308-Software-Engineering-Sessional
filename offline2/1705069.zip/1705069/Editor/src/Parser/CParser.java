package Parser;

public class CParser implements Parser {
    @Override
    public void parse() {
        System.out.println("Parsing c");
    }
}
