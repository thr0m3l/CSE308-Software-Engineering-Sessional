package Parser;

public interface Parser {
    public void parse();
}
