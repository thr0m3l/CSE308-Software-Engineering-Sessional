package Aesthetics;

public interface Aesthetics {
    public void setFont();

    public void setStyle();

    public void setColor();

}
