package Aesthetics;

public enum Font {
    CourierNew,
    Monaco,
    Consolas
}
