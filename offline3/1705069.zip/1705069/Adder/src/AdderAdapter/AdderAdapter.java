package AdderAdapter;

public interface AdderAdapter {
    public Integer calculateSum();

    public void fileConverter();
}
