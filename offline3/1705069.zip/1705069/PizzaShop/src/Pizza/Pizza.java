package Pizza;

public interface Pizza {
    public Double getPrice();
}
